package com.studentmanagement.example.DTO;

public class CreatingGradeDto {
    public Integer rate;
    public String description;
}
