package com.studentmanagement.example.DTO;

public class CreatingStudentDto {
    public String firstName;
    public String lastName;
}
