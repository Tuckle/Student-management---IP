package com.studentmanagement.example.services;

import com.studentmanagement.example.models.Student;

public interface StudentService extends CrudService<Student> {
}
